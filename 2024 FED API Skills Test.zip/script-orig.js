// Ambil data pasien Jessica Taylor dari API
fetch('https://fedskillstest.coalitiontechnologies.workers.dev', {
    headers: {
        'Authorization': 'Basic ' + btoa('coalition:skills-test')
    }
})
.then(response => response.json())
.then(data => {
    // Cari data Jessica Taylor
    const patient = data.find(p => p.name === "Jessica Taylor");

    if (patient) {
        // Isi informasi pasien di halaman
        document.getElementById('dateOfBirth').textContent = patient.date_of_birth;
        document.getElementById('patientGender').textContent = patient.gender;
        document.getElementById('patientPhone').textContent = patient.phone_number;
        document.getElementById('emergencyContact').textContent = patient.emergency_contact;
        document.getElementById('insuranceType').textContent = patient.insurance_type;
        document.getElementById('patientProfilePic').src = "assets/css/images/Layer 2.png"; // Gambar lokal

        // Isi data grafik (pastikan data diagnosis_history tersedia)
        if (patient.diagnosis_history && patient.diagnosis_history.length > 0) {
            const ctx = document.getElementById('bloodPressureChart').getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: patient.diagnosis_history.map(d => d.month + ' ' + d.year), // Gunakan data bulan dan tahun dari diagnosis_history
                    datasets: [
                        {
                            label: 'Systolic',
                            data: patient.diagnosis_history.map(d => d.blood_pressure.systolic.value),
                            borderColor: '#FF6384',
                            fill: false
                        },
                        {
                            label: 'Diastolic',
                            data: patient.diagnosis_history.map(d => d.blood_pressure.diastolic.value),
                            borderColor: '#36A2EB',
                            fill: false
                        }
                    ]
                }
            });
        } else {
            console.log('Diagnosis history not available for Jessica Taylor');
        }

        // Isi widget kecil seperti Respiratory Rate, Temperature, dan Heart Rate
        const latestDiagnosis = patient.diagnosis_history[0];
        document.getElementById('respiratoryRate').textContent = latestDiagnosis.respiratory_rate.value;
        document.getElementById('temperature').textContent = latestDiagnosis.temperature.value;
        document.getElementById('heartRate').textContent = latestDiagnosis.heart_rate.value;

        // Isi Lab Results (jika ada data hasil lab yang relevan)
        console.log('Lab Results:', patient.lab_results); // Debug data lab_results

		if (patient.lab_results && patient.lab_results.length > 0) {
			const labResultsList = document.getElementById('labResultsList');
			labResultsList.innerHTML = ''; // Kosongkan list terlebih dahulu
			patient.lab_results.forEach(result => {
				const li = document.createElement('li');
				li.textContent = result; // Sesuaikan dengan format lab_results
				labResultsList.appendChild(li);
			});
		} else {
			console.log('Lab results not available for Jessica Taylor or lab_results is empty');
		}
    } else {
        console.log('Jessica Taylor not found');
    }
})
.catch(error => console.error('Error:', error));
