fetch('https://fedskillstest.coalitiontechnologies.workers.dev', {
    method: 'GET',
    headers: {
        'Authorization': 'Basic ' + btoa('coalition:skills-test')
    }
})
.then(response => response.json())
.then(data => {
    // Cari data Jessica Taylor
    const patient = data.find(p => p.name === "Jessica Taylor");

    if (patient) {
        // Isi informasi pasien di halaman
        document.getElementById('dateOfBirth').textContent = patient.date_of_birth;
        document.getElementById('patientGender').textContent = patient.gender;
        document.getElementById('patientPhone').textContent = patient.phone_number;
        document.getElementById('emergencyContact').textContent = patient.emergency_contact;
        document.getElementById('insuranceType').textContent = patient.insurance_type;
        document.getElementById('patientProfilePic').src = "assets/css/images/Layer 2.png"; // Gambar lokal atau URL
        
        // Isi data grafik (pastikan data diagnosis_history tersedia)
        if (patient.diagnosis_history && patient.diagnosis_history.length > 0) {
            const ctx = document.getElementById('bloodPressureChart').getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: patient.diagnosis_history.map(d => d.month + ' ' + d.year), // Gunakan data bulan dan tahun dari diagnosis_history
                    datasets: [{
                        label: 'Systolic',
                        data: patient.diagnosis_history.map(d => d.blood_pressure.systolic.value),
                        borderColor: '#FF6384',
                        fill: false
                    },
                    {
                        label: 'Diastolic',
                        data: patient.diagnosis_history.map(d => d.blood_pressure.diastolic.value),
                        borderColor: '#36A2EB',
                        fill: false
                    }]
                },
				options: {
				maintainAspectRatio: false, // Ini memastikan grafik tidak terkunci pada rasio
				responsive: true,
				scales: {
					y: {
						beginAtZero: true
					}
				}
			}
            });
        } else {
            console.log('Diagnosis history not available for Jessica Taylor');
        }

        // Isi widget kecil untuk Respiratory Rate, Temperature, dan Heart Rate
        const latestDiagnosis = patient.diagnosis_history[0];
        document.getElementById('respiratoryRate').textContent = latestDiagnosis.respiratory_rate.value;
        document.getElementById('temperature').textContent = latestDiagnosis.temperature.value;
        document.getElementById('heartRate').textContent = latestDiagnosis.heart_rate.value;
		
		// Mengisi Diagnostic List jika data tersedia
		if (patient.diagnostic_list && patient.diagnostic_list.length > 0) {
			const diagnosticTableBody = document.querySelector('#diagnosticTable tbody');
			diagnosticTableBody.innerHTML = ''; // Kosongkan terlebih dahulu

			patient.diagnostic_list.forEach(diagnostic => {
				const row = document.createElement('tr');
				row.innerHTML = `
					<td>${diagnostic.name}</td>
					<td>${diagnostic.description}</td>
					<td>${diagnostic.status}</td>
				`;
				diagnosticTableBody.appendChild(row);
			});
		} else {
			console.log('No diagnostic data available for Jessica Taylor');
		}

        // Isi Lab Results (jika ada data hasil lab yang relevan)
        console.log('Lab Results:', patient.lab_results); // Debug data lab_results
        if (patient.lab_results && patient.lab_results.length > 0) {
            const labResultsList = document.getElementById('labResultsList');
            labResultsList.innerHTML = ''; // Kosongkan list terlebih dahulu
            patient.lab_results.forEach(result => {
                const li = document.createElement('li');
                li.innerHTML = `${result} <img src="assets/css/images/download_FILL0_wght300_GRAD0_opsz24 (1).svg" class="lab-result-icon" alt="Download Icon">`;
                labResultsList.appendChild(li);
            });
        } else {
            console.log('Lab results not available for Jessica Taylor');
        }
    } else {
        console.log('Jessica Taylor not found');
    }
})
.catch(error => console.error('Error:', error));
